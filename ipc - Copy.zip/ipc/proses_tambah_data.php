<?php

include('koneksi.php');

$kode = $_POST['kode'];
$nama_bahan = $_POST['nama_bahan'];
$sumber = $_POST['sumber'];

$air = floatval(str_replace(',', '.', $_POST['air']));
$energi = floatval(str_replace(',', '.', $_POST['energi']));
$protein = floatval(str_replace(',', '.', $_POST['protein']));
$lemak = floatval(str_replace(',', '.', $_POST['lemak']));
$kh = floatval(str_replace(',', '.', $_POST['kh']));
$serat = floatval(str_replace(',', '.', $_POST['serat']));
$abu = floatval(str_replace(',', '.', $_POST['abu']));
$kalsium = floatval(str_replace(',', '.', $_POST['kalsium']));
$fosfor = floatval(str_replace(',', '.', $_POST['fosfor']));
$besi = floatval(str_replace(',', '.', $_POST['besi']));
$natrium = floatval(str_replace(',', '.', $_POST['natrium']));
$kalium = floatval(str_replace(',', '.', $_POST['kalium']));
$tembaga = floatval(str_replace(',', '.', $_POST['tembaga']));
$seng = floatval(str_replace(',', '.', $_POST['seng']));
$retinol = floatval(str_replace(',', '.', $_POST['retinol']));
$b_kar = floatval(str_replace(',', '.', $_POST['b_kar']));
$kar_total = floatval(str_replace(',', '.', $_POST['kar_total']));
$thiamin = floatval(str_replace(',', '.', $_POST['thiamin']));
$riboflavin = floatval(str_replace(',', '.', $_POST['riboflavin']));
$niasin = floatval(str_replace(',', '.', $_POST['niasin']));
$vit_c = floatval(str_replace(',', '.', $_POST['vit_c']));
$bdd = floatval(str_replace(',', '.', $_POST['bdd']));


$stmt = $conn->prepare("INSERT INTO tabel_data_kpi (kode, nama_bahan, sumber, air, energi, protein, lemak, kh, serat, abu, kalsium, fosfor, besi, natrium, kalium, tembaga, seng, retinol, b_kar, kar_total, thiamin, riboflavin, niasin, vit_c, bdd) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

$stmt->bind_param("sssdddddddddddddddddddddd", 
    $kode, $nama_bahan, $sumber, $air, $energi, $protein, $lemak, $kh, $serat, $abu, 
    $kalsium, $fosfor, $besi, $natrium, $kalium, $tembaga, $seng, $retinol, 
    $b_kar, $kar_total, $thiamin, $riboflavin, $niasin, $vit_c, $bdd);

if ($stmt->execute()) {
    header("Location: sho.php");
    exit();
} else {
    echo "Data Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>