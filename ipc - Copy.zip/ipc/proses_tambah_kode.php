<?php

include "koneksi.php";

if($_SERVER["REQUEST_METHOD"]== "POST"){
   $id = $_POST['id'];
$kelompok = $_POST ['kelompok'];
$kode = $_POST ['kode'];


   $query = "UPDATE tabel_data_kode SET kelompok='$kelompok', kode='$kode'";
   $result = mysqli_query($conn, $query);

   if ($result){
      header("Location:pbp.php");
      exit();
   } else {
      header("Location:pbp.php");
      exit();
   }
}

?>