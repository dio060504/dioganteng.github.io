<?php
    include"koneksi.php";

    if (isset($_GET['id'])) {
        $id_nomor = $_GET['id'];

        echo "ID data yang diterima: ". $id_nomor;

        $sql = "DELETE FROM tabel_data_kpi WHERE id_nomor = $id_nomor";

        if ($conn->query($sql) === TRUE) {
            header ("Location: sho.php");
            exit();
        } else {
            echo "Error: ". $sql. "<br>". $conn->error;
        }
    } else {
        echo "ID data tidak di temukan";
    }
    $conn->close();
    ?>