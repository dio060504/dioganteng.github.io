/*
Template Name: Abstack - Bootstrap 4 Web App kit
Author: CoderThemes
File: Responsive table init js
*/

$(function() {
    $('.table-responsive').responsiveTable({
        addDisplayAllBtn: 'btn btn-secondary'
    });
});
