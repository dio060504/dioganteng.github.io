/*
Template Name: Abstack - Bootstrap 4 Web App kit
Author: CoderThemes
File: Form validation init js
*/

$(document).ready(function() {
    $('.parsley-examples').parsley();
});