/*
Template Name: Abstack - Bootstrap 4 Web App kit
Author: CoderThemes
File: Tablesaw tables init js
*/

$( function(){
    $( document ).trigger( "enhance.tablesaw" );
});
